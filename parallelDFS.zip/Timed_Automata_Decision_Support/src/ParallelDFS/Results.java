package ParallelDFS;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

public class Results{
	static ArrayList<Node>bestTrace;
	static double cost=Float.POSITIVE_INFINITY;
	static ArrayList<DFSTask> threads=new ArrayList<DFSTask>();

	synchronized void addThread(DFSTask e){
		threads.add(e);
	}

	synchronized void removeThread(DFSTask e){
		threads.remove(e);
	}

	static synchronized void checkResult(ArrayList<Node> trace, double cost){
		if(cost<Results.cost){
			Results.cost=cost;
			Results.bestTrace=trace;
			
			System.out.println("Notified new cost " +Results.cost +"\n");
			//System.out.println("Notified new cost " +Results.cost +"\n"+bestTrace.toString());
		}
	}
}
