package ParallelDFS;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TimeUnit;

import ParallelDFS.Node.Execution;






public class ParallelDFS {

	Model model;
	ArrayList<Node> nodeQueue;
	
	public ParallelDFS(Model m) {
		this.model=m;
		this.nodeQueue=new ArrayList<Node>();	
	}

	private void init(int startingNodes, int depth, int nThreads, Fragment destination) {
		Fragment root=model.getRoot();

		if(root.isOffloadable){
			nodeQueue.add(new Node(root, root.getLocalCost(), null, 0, Execution.MOBILE));
			nodeQueue.add(new Node(root, root.getRemoteCost(), null, 0, Execution.CLOUD));
			nodeQueue.add(new Node(root, root.getLocalCost()+root.getTransferCost(), null, 0, Execution.MOBILE_BUS));
			nodeQueue.add(new Node(root, root.getRemoteCost()+root.getTransferCost(), null, 0, Execution.CLOUD_BUS));
		}else{
			nodeQueue.add(new Node(root, root.getLocalCost(), null, 0, Execution.MOBILE));
			nodeQueue.add(new Node(root, root.getLocalCost()+root.getTransferCost(), null, 0, Execution.MOBILE_BUS));
		}

		computeDykstra(startingNodes, depth, nThreads, destination);
	}

	private void computeDykstra(int tHREADNUMBER, int depth, int nThreads, Fragment destination) {
		while(nodeQueue.size()<tHREADNUMBER){
			ArrayList<Node>current=new ArrayList<Node>();
			for (Node node : nodeQueue) {
				current.addAll(model.calculateNext(node));
			}
			nodeQueue.clear();
			nodeQueue.addAll(current);
		}
		System.out.println(nodeQueue);


		ExecutorService exec = Executors.newFixedThreadPool(nThreads);
		List<Future<ArrayList<Node>>>results= new ArrayList<Future<ArrayList<Node>>>();
		int i = 0;
		for (Node n:nodeQueue) {
			DFSTask d=new DFSTask("Thread"+i++,model.getInstance(), n, depth, destination);
			Results.threads.add(d);
			results.add(exec.submit(d));
		}


		for (Future<ArrayList<Node>> future : results) {
			try {
				ArrayList<Node>partialResult=future.get();
				if (partialResult!=null) {
					Results.checkResult(partialResult, partialResult.get(partialResult.size()-1).getMinCost());
				}
				future.cancel(true);
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		System.out.println(Results.bestTrace.toString());
		exec.shutdown();
	}





	public static void main(String args[]) {
		long startTime = System.currentTimeMillis();
		Fragment f0=new Fragment("0", true, 4, 12, 25);
		Fragment f1=new Fragment("1", true, 50, 12, 22);
		Fragment f2=new Fragment("2", true, 53, 12, 22);
		Fragment f3=new Fragment("3", true, 46, 22, 22);
		Fragment f4=new Fragment("4", true, 33, 9, 25);//		
		f0.setND(new Fragment[]{f2});
		f1.setND(new Fragment[]{f4});
		f2.setSEQ(new Fragment[]{f3, f1});
		f3.setND(new Fragment[]{f0});
		f4.setND(new Fragment[]{f2});
		
//		Fragment f0=new Fragment("0", false, 4, 12, 25);
//		Fragment f1=new Fragment("1", true, 50, 12, 22);
//		Fragment f2=new Fragment("2", true, 53, 12, 22);
//		f0.setND(new Fragment[]{f2});
//		f1.setND(new Fragment[]{f2});
//		f2.setSEQ(new Fragment[]{f0, f1});


		Model m=new Model(16,16*3,50);
		m.setRoot("0");
		m.addFragment(new Fragment[]{f0, f1, f2,f3,f4});
//		m.addFragment(new Fragment[]{f0, f1, f2});
		System.out.println("F0: "+ f0.getLocalCost()+"  "+f0.getRemoteCost()+"  "+f0.getTransferCost());
		System.out.println("F1: "+ f1.getLocalCost()+"  "+f1.getRemoteCost()+"  "+f1.getTransferCost());
		System.out.println("F2: "+ f2.getLocalCost()+"  "+f2.getRemoteCost()+"  "+f2.getTransferCost());
//		System.out.println("F3: "+ f3.getLocalCost()+"  "+f3.getRemoteCost()+"  "+f3.getTransferCost());
//		System.out.println("F4: "+ f4.getLocalCost()+"  "+f4.getRemoteCost()+"  "+f4.getTransferCost());


		ParallelDFS algorithm=new ParallelDFS(m);
					final int STARTINGNODES=2;
//		final int STARTINGNODES=Integer.valueOf(args[0]);
					final short DEPTH=45;
//		final short DEPTH=Short.valueOf(args[1]);
		//final short NTHREADS=Short.valueOf(args[2]);
					final short NTHREADS=3;
		algorithm.init(STARTINGNODES, DEPTH, NTHREADS, f0);
		System.out.println("EXPERIMENT DFS: startingNodes="+STARTINGNODES+" depth="+DEPTH+" nthreads="+NTHREADS+ " timeUsed="+(System.currentTimeMillis()-startTime));
		//System.out.println("Elapsing of time in ms:" + (System.currentTimeMillis()-startTime));
	}




}
