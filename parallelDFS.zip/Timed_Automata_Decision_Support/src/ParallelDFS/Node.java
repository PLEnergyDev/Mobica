package ParallelDFS;




public class Node{
	
	public enum Execution{
		MOBILE, CLOUD, MOBILE_BUS, CLOUD_BUS
	}


	private Fragment currentFragment;
	private double minCost=Float.POSITIVE_INFINITY;
	private Node previous;
	private int depthLevel;
	private Execution execution;
	
	
	public Node(Fragment currentFragment, double minCost, Node previous,
			int depthLevel, Execution ex) {
		super();
		this.currentFragment = currentFragment;
		this.minCost = minCost;
		this.previous = previous;
		this.depthLevel = depthLevel;
		this.execution = ex;
	}
	


	public Fragment getCurrentFragment() {
		return currentFragment;
	}



	public double getMinCost() {
		return minCost;
	}



	public int getDepthLevel() {
		return depthLevel;
	}



	public Execution getExecution() {
		return execution;
	}



	
	public Node getPrevious() {
		return previous;
	}



	@Override
	public String toString() {
		return "Fragment "+currentFragment +" with cost "+ minCost+ " executed " + execution+ " at level " + depthLevel+"\n";
	}
	
	
}

