package ParallelDFS;



import java.util.ArrayList;
import java.util.Collections;
import java.util.Observable;
import java.util.Observer;
import java.util.PriorityQueue;
import java.util.concurrent.Callable;


public class DFSTask implements Callable<ArrayList<Node>>{

	private final Object lock = new Object();
	Model model;
	Node init;
	int depth;
	Fragment destination;
	String name;
	double bestTraceCost=Float.POSITIVE_INFINITY;
	ArrayList<Node> shortestTaskPath;


	public DFSTask(String name, Model model, Node init,int depth, Fragment destination){
		this.model=model;
		this.init=init;
		this.depth=depth;
		this.destination=destination;
		this.name=name;
	}
	
	public void DFS(Node n){
		for (Node currentNode : model.calculateNext(n)) {
			if (currentNode.getCurrentFragment().getId().equals(destination.getId()) && currentNode.getDepthLevel()>depth) {
				getShortestPath(currentNode);
			}else if (currentNode.getMinCost()>bestTraceCost) {
//				System.out.println(name +" closed for bad result");
			}else{
				DFS(currentNode);
			}
			
				
		}
	}

	@Override
	public ArrayList<Node> call() throws Exception {
		 DFS(init);
		// System.out.println( name +" concluded with costs: "+bestTraceCost+"and name");
		 return shortestTaskPath;
	}

	private void getShortestPath(Node target) {
		if(target.getMinCost()<this.bestTraceCost){
			this.bestTraceCost=target.getMinCost();
			shortestTaskPath=new ArrayList<Node>();
			for (Node vertex =target; vertex != null; vertex = vertex.getPrevious()){
				shortestTaskPath.add(vertex);
			}
			Collections.reverse(shortestTaskPath);
//			System.out.println( name +" concluded another task");
		}
	}

}
