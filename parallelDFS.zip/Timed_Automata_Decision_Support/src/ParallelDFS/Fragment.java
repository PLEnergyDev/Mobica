package ParallelDFS;

import java.util.HashMap;
import java.util.Random;


public class Fragment {

	String id;
	boolean isOffloadable, init;
	float instructions, memory, transferedByte;
	float localCost, remoteCost, transferCost;
	Fragment[] ND, SEQ, PAR=null;

	public Fragment(String id, boolean isOffloadable,
			float instructions, float memory, float transferedByte) {
		this.id = id;
		this.isOffloadable = isOffloadable;
		this.instructions = instructions;
		this.memory = memory;
		this.transferedByte = transferedByte;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isOffloadable() {
		return isOffloadable;
	}

	public void setOffloadable(boolean isOffloadable) {
		this.isOffloadable = isOffloadable;
	}

	public boolean isInit() {
		return init;
	}

	public void setInit(boolean init) {
		this.init = init;
	}

	public float getMemory() {
		return memory;
	}

	public void setMemory(float memory) {
		this.memory = memory;
	}

	public float getTransferedByte() {
		return transferedByte;
	}

	public void setTransferedByte(float transferedByte) {
		this.transferedByte = transferedByte;
	}

	public float getLocalCost() {
		return localCost;
	}

	public void setLocalCost(float mobileInst) {
		this.localCost = instructions/mobileInst;
	}

	public float getRemoteCost() {
		return remoteCost;
	}

	public void setRemoteCost(float cloudIns) {
		this.remoteCost = instructions/cloudIns;
	}

	public float getTransferCost() {
		return transferCost;
	}

	public void setTransferCost(float netwBand) {
		this.transferCost = transferedByte/netwBand;
	}

	public void setND(Fragment[] nD) {
		ND = nD;
	}

	public void setSEQ(Fragment[] sEQ) {
		SEQ = sEQ;
	}

	public void setPAR(Fragment[] pAR) {
		PAR = pAR;
	}
	@Override
	public String toString() {
		return id;
	}

}
