package ParallelDjkstra;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

public class Results{
	static ArrayList<Node>bestTrace;
	static float cost=Float.POSITIVE_INFINITY;
	static ArrayList<DjkstraTask> threads=new ArrayList<DjkstraTask>();

	synchronized void addThread(DjkstraTask e){
		threads.add(e);
	}

	synchronized void removeThread(DjkstraTask e){
		threads.remove(e);
	}

	static synchronized void checkResult(ArrayList<Node> trace, float cost){
		if(cost<Results.cost){
			Results.cost=cost;
			Results.bestTrace=trace;
			for (DjkstraTask task : threads) {
					task.updateCost(Results.cost);

			}
			System.out.println("Notified new cost " +Results.cost );
		}
	}
}
