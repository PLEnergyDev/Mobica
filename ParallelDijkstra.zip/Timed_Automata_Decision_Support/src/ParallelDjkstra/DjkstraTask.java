package ParallelDjkstra;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Observable;
import java.util.Observer;
import java.util.PriorityQueue;
import java.util.concurrent.Callable;

import ParallelDjkstra.Node.Execution;

public class DjkstraTask implements Callable<ArrayList<Node>>{

	private final Object lock = new Object();
	Model model;
	Node init;
	PriorityQueue<Node>nodeQueue;
	int depth;
	Fragment destination;
	String name;
	float cost=Float.POSITIVE_INFINITY;


	public DjkstraTask(String name, Model model, Node init,int depth, Fragment destination){
		this.model=model;
		this.init=init;
		this.nodeQueue=new PriorityQueue<Node>();
		this.nodeQueue.add(init);
		this.depth=depth;
		this.destination=destination;
		this.name=name;
	}

	@Override
	public ArrayList<Node> call() throws Exception {
		boolean found=false;
		Node n=new Node(null, 0, null, 0, null);
		while(!nodeQueue.isEmpty() && !found ){
			n=nodeQueue.poll();
			nodeQueue.addAll(model.calculateNext(n));
			if(n.getCurrentFragment().getId().equals(destination.getId()) && n.getDepthLevel()>depth){
				found=true;
				return getShortestPath(n);
			}else if (n.getMinCost()>getCost()) {
				//System.out.println(name +" closed for bad results");
				dispose();
				return null;

			}
		}
		return null;
	}

	private ArrayList<Node> getShortestPath(Node target) {
		ArrayList<Node> shortestTaskPath=new ArrayList<Node>();
		for (Node vertex =target; vertex != null; vertex = vertex.getPrevious()){
			shortestTaskPath.add(vertex);
		}
		Collections.reverse(shortestTaskPath);
		System.out.println( name +" concluded with N° of nodes " +nodeQueue.size()+ " and costs: "+target.getMinCost()+"and name" + target.getCurrentFragment() );
		dispose();
		return shortestTaskPath;
	}



	public void updateCost(float cost) {
			this.cost=cost;	
//			System.out.println("Recived new cost " +getCost() +" at "+ name);

	}

	public float getCost(){
			return this.cost;	
	}


	public void dispose(){
		nodeQueue=null;
		model=null;
	}

}
