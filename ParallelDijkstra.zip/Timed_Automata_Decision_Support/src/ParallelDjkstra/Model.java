package ParallelDjkstra;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

import javax.swing.GroupLayout.SequentialGroup;

import ParallelDjkstra.Node.Execution;

public class Model implements Cloneable {

	Hashtable<String, Fragment> fragmetsList;
	String root;
	int mobileInst, cloudInst;
	float networkBand;

	public Model(int mobileInst, int cloudInst, float networkBand) {
		this.fragmetsList=new Hashtable<String, Fragment>();
		this.mobileInst = mobileInst;
		this.cloudInst = cloudInst;
		this.networkBand = networkBand;
	}



	public Fragment getRoot() {
		return this.fragmetsList.get(root);
	}

	public void setRoot(String root) {
		this.root = root;
	}

	public void addFragment(Fragment[] fragments){
		for (Fragment f:fragments) {
			f.setLocalCost(mobileInst);
			f.setRemoteCost(cloudInst);
			f.setTransferCost(networkBand);
			fragmetsList.put(f.getId(), f);
		}	
	}


	public synchronized Model getInstance(){
		try {
			return (Model) this.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return null;
	}
	Hashtable<Integer, Integer> sequencialLevel=new Hashtable<Integer, Integer>(); 
	int successorFragment=0;
	public ArrayList<Node> calculateNext(Node node){
		ArrayList<Node>nodeQueue=new ArrayList<Node>();
		Fragment[] successorsList =null;
		if(node.getCurrentFragment().ND!=null){
			successorsList=node.getCurrentFragment().ND;
		}else if (node.getCurrentFragment().SEQ!=null) {
			if (sequencialLevel.get(node.getDepthLevel())!=null) {
				successorsList=new Fragment[]{node.getCurrentFragment().SEQ[sequencialLevel.get(node.getDepthLevel())]};
			}else{
				successorsList=new Fragment[]{node.getCurrentFragment().SEQ[successorFragment%node.getCurrentFragment().SEQ.length]};
				sequencialLevel.put(node.getDepthLevel(), successorFragment%node.getCurrentFragment().SEQ.length);
				successorFragment++;
			}
		}

		for (Fragment fragment : successorsList) {
			if(fragment.isOffloadable){
				switch (node.getExecution()) {
				case MOBILE:
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getLocalCost(), node, node.getDepthLevel()+1, Execution.MOBILE));
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getLocalCost()+fragment.getTransferCost(), node, node.getDepthLevel()+1, Execution.MOBILE_BUS));
					break;
				case CLOUD:
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getRemoteCost(), node, node.getDepthLevel()+1, Execution.CLOUD));
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getRemoteCost()+fragment.getTransferCost(), node, node.getDepthLevel()+1, Execution.CLOUD_BUS));
					break;
				case CLOUD_BUS:
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getLocalCost(), node, node.getDepthLevel()+1, Execution.MOBILE));
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getLocalCost()+fragment.getTransferCost(), node, node.getDepthLevel()+1, Execution.MOBILE_BUS));
					break;
				case MOBILE_BUS:
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getRemoteCost(), node, node.getDepthLevel()+1, Execution.CLOUD));
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getRemoteCost()+fragment.getTransferCost(), node, node.getDepthLevel()+1, Execution.CLOUD_BUS));
					break;
				default:
					break;
				}
			}else{
				switch (node.getExecution()) {
				//case MOBILE_BUS:
				case CLOUD_BUS:case MOBILE:
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getLocalCost(), node, node.getDepthLevel()+1, Execution.MOBILE));
					nodeQueue.add(new Node(fragment, node.getMinCost()+fragment.getLocalCost()+fragment.getTransferCost(), node, node.getDepthLevel()+1, Execution.MOBILE_BUS));
					break;
				case CLOUD:
					break;
				default:
					break;

				}
			}
		}


		return nodeQueue;
	}


}
